export default function Files() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Files</h1>
      {/* Files content will be implemented next */}
    </div>
  );
}