export default function Forum() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Forum</h1>
      {/* Forum content will be implemented next */}
    </div>
  );
}