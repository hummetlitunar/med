export default function Profile() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Profile</h1>
      {/* Profile content will be implemented next */}
    </div>
  );
}